package app.api;

import java.util.List;
import java.util.ArrayList;

import app.model.Tweet;
import flexjson.JSONDeserializer;
import flexjson.JSONSerializer;

public class JsonParsers
{
  public static JSONSerializer tweetSerializer     = new JSONSerializer().exclude("class")
                                                                        .exclude("persistent")
                                                                        .exclude("entityId"); 
  public static Tweet json2Tweet(String json)
  {
    return new JSONDeserializer<Tweet>().deserialize(json, Tweet.class); 
  }

  public static List<Tweet> json2Tweets(String json)
  {
    return new JSONDeserializer<ArrayList<Tweet>>().use("values", Tweet.class)
                                                  .deserialize(json);
  }

  public static String tweet2Json(Object obj)
  {
    return tweetSerializer.serialize(obj);
  }

  public static List<Tweet> tweets2Json(String json)
  {
    return new JSONDeserializer<ArrayList<Tweet>>().use("values", Tweet.class)
                                                  .deserialize(json);
  } 
  
}
