package org.wit.myrent.activities;

import java.util.UUID;

import org.wit.myrent.R;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;

public class MyRentActivity extends FragmentActivity
{
  public void onCreate(Bundle savedInstanceState)
  {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.fragment_container);

    FragmentManager manager = getSupportFragmentManager();
    Fragment fragment = manager.findFragmentById(R.id.fragmentContainer);
    if (fragment == null)
    {
      fragment = createFragment();
      manager.beginTransaction().add(R.id.fragmentContainer, fragment).commit();
    }
  }

  protected Fragment createFragment()
  {
    UUID resId = (UUID)getIntent().getSerializableExtra(MyRentFragment.EXTRA_RESIDENCE_ID);
    return MyRentFragment.newInstance(resId);
  }
}
