package org.wit.myrent.activities;

import java.util.ArrayList;
import java.util.UUID;

import org.wit.myrent.R;
import org.wit.myrent.app.MyRentApp;
import org.wit.myrent.models.Portfolio;
import org.wit.myrent.models.Residence;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import static org.wit.android.helpers.LogHelpers.info;

public class MyRentPagerActivity extends FragmentActivity implements ViewPager.OnPageChangeListener
{
  private ViewPager             viewPager;
  private ArrayList<Residence>  residences;  
  private Portfolio             portfolio; 
  private PagerAdapter          pagerAdapter;
  
  @Override
  public void onCreate(Bundle savedInstanceState) 
  {
    super.onCreate(savedInstanceState);
    viewPager = new ViewPager(this);
    viewPager.setId(R.id.viewPager);
    setContentView(viewPager);
    setResidenceList();
    pagerAdapter = new PagerAdapter(getSupportFragmentManager(), residences);
    viewPager.setAdapter(pagerAdapter);
    backButton();
    viewPager.setOnPageChangeListener(this);
  }
  
  private void setResidenceList()
  {
    MyRentApp app = (MyRentApp) getApplication();
    portfolio = app.portfolio; 
    residences = portfolio.residences;    
  }
  
  private void backButton()
  {
    //On pressing back button display move to position on list that includes current residence
    UUID res = (UUID) getIntent().getSerializableExtra(MyRentFragment.EXTRA_RESIDENCE_ID);
    for (int i = 0; i < residences.size(); i++)
    {
      if (residences.get(i).id.toString().equals(res.toString()))
      {
        viewPager.setCurrentItem(i);
        break;
      }
    }
  }
  
  //Three following methods: on page change listener
  /*
   * (non-Javadoc)
   * @see android.support.v4.view.ViewPager.OnPageChangeListener#onPageScrolled(int, float, int)
   * set the page title
   */
  @Override
  public void onPageScrolled(int arg0, float arg1, int arg2)
  {
    info(this, "onPageScrolled: arg0 "+arg0+" arg1 "+arg1+" arg2 "+arg2);
    Residence residence = residences.get(arg0);
    if (residence.geolocation != null)
    {
      setTitle(residence.geolocation);
    }
  }
  @Override
  public void onPageSelected(int pos)
  {
  }
  
  @Override
  public void onPageScrollStateChanged(int arg0)
  {
    info(this, "onPageScrollStateChanged: arg0 "+arg0);
  }

  class PagerAdapter extends FragmentStatePagerAdapter 
  {
    private ArrayList<Residence>  residences; 
  
    public PagerAdapter(FragmentManager fm, ArrayList<Residence> residences)
    {
      super(fm);
      this.residences = residences;
    }
    
    @Override
    public int getCount()  
    {  
      return residences.size();  
    }
    
    @Override
    public Fragment getItem(int pos) 
    {
      Residence residence = residences.get(pos);
      Bundle args = new Bundle();
      args.putSerializable(MyRentFragment.EXTRA_RESIDENCE_ID, residence.id);
      MyRentFragment fragment = new MyRentFragment();
      fragment.setArguments(args);
      return fragment;
    } 
  }
}