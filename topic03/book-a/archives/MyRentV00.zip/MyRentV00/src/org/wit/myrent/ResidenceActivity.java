package org.wit.myrent;

import android.app.Activity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;

public class ResidenceActivity extends Activity implements TextWatcher
{
  private EditText  geolocation;
  private Residence residence;

  @Override
  protected void onCreate(Bundle savedInstanceState)
  {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_myrent);
    geolocation = (EditText) findViewById(R.id.geolocation);
    residence = new Residence();

    geolocation.addTextChangedListener(this);
  }

  @Override
  public boolean onCreateOptionsMenu(Menu menu)
  {
    getMenuInflater().inflate(R.menu.my_rent, menu);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item)
  {
    int id = item.getItemId();
    if (id == R.id.action_settings)
    {
      return true;
    }
    return super.onOptionsItemSelected(item);
  }

  @Override
  public void afterTextChanged(Editable c)
  {
    residence.setGeolocation(c.toString());
  }

  @Override
  public void beforeTextChanged(CharSequence c, int start, int count, int after)
  {
  }

  @Override
  public void onTextChanged(CharSequence c, int start, int count, int after)
  {
  }
}
