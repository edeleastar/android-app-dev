package app.activities;

import java.util.List;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import app.donation.R;
import app.main.DonationApp;
import app.models.Donation;
import app.services.RefreshService;
import app.settings.SettingsActivity;


public class Report extends Activity
{
  public static final String BROADCAST_ACTION = "app.activities.Report";
  private ListView        listView;
  private DonationApp     app;
  private DonationAdapter adapter; 
  private IntentFilter intentFilter;
  @Override
  public boolean onCreateOptionsMenu(Menu menu)
  {
    getMenuInflater().inflate(R.menu.report, menu);
    return true;
  }
  
  @Override
  public boolean onOptionsItemSelected(MenuItem item)
  {
    switch (item.getItemId())
    {
      case R.id.menuDonate : startActivity (new Intent(this, Donate.class));
                             break;
      case R.id.menuLogout : startActivity (new Intent(this, Welcome.class));
                             break;                               

      case R.id.action_refresh: startService(new Intent(this, RefreshService.class));
                                return true;
      case R.id.action_settings:
        startActivity(new Intent(this, SettingsActivity.class));
        return true;
    
    }
    return true;
  }  
  
  @Override
  public void onCreate(Bundle savedInstanceState)
  {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_report);

    app = (DonationApp) getApplication();

    listView = (ListView) findViewById(R.id.reportList);
    adapter = new DonationAdapter (this, app.donations);

    listView.setAdapter(adapter);
    intentFilter = new IntentFilter(BROADCAST_ACTION);
    registerBroadcastReceiver(intentFilter);
  }
  private void registerBroadcastReceiver(IntentFilter intentFilter)
  {
    ResponseReceiver mResponseReceiver = new ResponseReceiver();
    // Registers the ResponseReceiver and its intent filters
    LocalBroadcastManager.getInstance(this).registerReceiver(mResponseReceiver, intentFilter);
  }
  
  private class ResponseReceiver extends BroadcastReceiver
  {
    private void ResponseReceiver()
    {
    }

    // Called when the BroadcastReceiver gets an Intent it's registered to receive
    @Override
    public void onReceive(Context context, Intent intent)
    {
      adapter.donations = app.donations;
      adapter.notifyDataSetChanged();
    }

  }
  
}

class DonationAdapter extends ArrayAdapter<Donation>
{
  private Context        context;
  public  List<Donation> donations;

  public DonationAdapter(Context context, List<Donation> donations)
  {
    super(context, R.layout.row_donate, donations);
    this.context   = context;
    this.donations = donations;
  }

  @Override
  public View getView(int position, View convertView, ViewGroup parent)
  {
    LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
 
    View     view       = inflater.inflate(R.layout.row_donate, parent, false);
    Donation donation   = donations.get(position);
    TextView amountView = (TextView) view.findViewById(R.id.row_amount);
    TextView methodView = (TextView) view.findViewById(R.id.row_method);
    
    amountView.setText("" + donation.amount);
    methodView.setText(donation.method);
    
    return view;
  }

  @Override
  public int getCount()
  {
    return donations.size();
  }
}