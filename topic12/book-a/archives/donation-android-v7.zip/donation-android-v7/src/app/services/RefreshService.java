package app.services;

import java.util.List;

import android.app.IntentService;
import android.content.Intent;
import android.helpers.LogHelpers;
import android.support.v4.content.LocalBroadcastManager;
import app.activities.Report;
import app.http.Rest;
import app.main.DonationApp;
import app.models.Donation;
import app.models.JsonParsers;

public class RefreshService extends IntentService
{
  DonationApp app;

  
  public RefreshService()
  {
    super("RefreshService");
  }

  @Override
  public void onCreate()
  {
    super.onCreate();
    LogHelpers.info(this, "onCreated");
    app = (DonationApp)getApplication();
  }
  
  /*
   * invoked on worker thread(non-Javadoc)
   * @see android.app.IntentService#onHandleIntent(android.content.Intent)
   */
  @Override
  protected void onHandleIntent(Intent intent)
  {
    try
    {
      String response =  Rest.get("/api/users/" + app.currentUser.id + "/donations");//[1]
      List<Donation> donationList = JsonParsers.json2Donations(response);//[2]
      app.donations  = donationList; //[3] 
      LogHelpers.info(this, "Donation list received");//[4]
      broadcastIntent();
    }
    catch(Exception e)//[5]
    {
      LogHelpers.info(this, "failed to retrieve donations : " + e.getMessage());      
    }    
  }
  private void broadcastIntent()
  {

    Intent localIntent = new Intent(Report.BROADCAST_ACTION);
    // Broadcasts the Intent to receivers in this app.
    LocalBroadcastManager.getInstance(this).sendBroadcast(localIntent);
  }
  
  @Override
  public void onDestroy()
  {
    super.onDestroy();
    LogHelpers.info(this, "onDestroyed");
  }
}