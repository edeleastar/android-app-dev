package models;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import java.util.ArrayList;
import java.util.List;

import play.db.jpa.Model;

/*
Enclose User in ` ` when deploying to Heroku.
This is necessary because User is a reserved word in PostGreSQL.
However, comment out to see User at localhost:9000/@db
*/
@Entity
@Table(name="`User`") 
public class User extends Model
{
  public String firstName;
  public String lastName;
  public String email;
  public String password;
  
  @OneToMany(cascade = CascadeType.ALL)
  public List<Donation> donations = new ArrayList<Donation>();

  public User(String firstName, String lastName, String email, String password)
  {
    this.firstName = firstName;
    this.lastName = lastName;
    this.email = email;
    this.password = password;
  } 
}