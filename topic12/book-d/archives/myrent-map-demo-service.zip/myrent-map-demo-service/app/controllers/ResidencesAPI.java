package controllers;

import java.util.List;
import java.util.Random;

import models.Residence;
import models.Residence;
import models.User;
import play.Logger;
import play.mvc.Controller;
import utils.JsonParsers;

import com.google.gson.JsonElement;

public class ResidencesAPI extends Controller
{
  public static void residences(String userId)
  {
    User user = User.findById(userId);
    if(user == null)
    {
      notFound();
    }
    else
    {
      List<Residence> residences = Residence.findAll();
      renderJSON(JsonParsers.residence2Json(residences));
    }
  }
  
  public static void residence(String userId, String id)
  {
    User user = User.findById(userId);
    if(user == null)
    {
      notFound();
    }
    else
    {
      Residence residence = Residence.findById(id);  
      if (user.residences.contains(residence))
      {
        renderJSON(JsonParsers.residence2Json(residence));
      }
      else
      {
        badRequest();
      }
    }
  }
 
  public static void residence(String id)
  {
    Residence res = Residence.findById(id);  
    if (res == null)
    {
      notFound();
    }
    else
    {
      renderJSON(JsonParsers.residence2Json(res));
    }
  }
  
  public static void createResidence(String userId, JsonElement body)
  {
    User user = User.findById(userId);
    Residence residence = JsonParsers.json2Residence(body.toString());
    user.residences.add(residence);  
    residence.user = user; //required for USER_ID in Table RESIDENCE
    residence.save();
    renderJSON (JsonParsers.residence2Json(residence));

  }
 
  /**
   * Update by finding res to be updated, deleting it and saving replacement
   * @param userId
   * @param body
   */
  public static void updateResidence(String userId, JsonElement body)
  {
    User user = User.findById(userId);
    Residence residence = JsonParsers.json2Residence(body.toString());
    List<Residence> residences = user.residences;
    for(int j = 0; j < residences.size(); j += 1)
    {
      Residence r = residences.get(j);
      if(r.uuid.equals(residence.uuid))
      {
        r.delete();
        residence.user = user;
        residence.save();
        break;
      }
    }
    renderJSON (JsonParsers.residence2Json(residence));

  }
  
  public static void deleteResidence(String id)
  {
    Residence residence = Residence.findById(id);
    if (residence == null)
    {
      notFound();
    }
    else
    {
      residence.delete();
      renderText("success");
    }
  }
   
  public static void deleteAllResidences()
  {
    List<User> users = User.findAll();
    for(int i = 0; i < users.size(); i += 1)
    {
      User user = users.get(i);
      List<Residence> residences = user.residences;
      for(int j = 0; j < residences.size(); j += 1)
      {
        deleteResidence(residences.get(j).uuid);
      }
    }
    renderText("success");  
  }
}
