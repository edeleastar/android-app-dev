package controllers;

import java.util.List;

import models.Residence;
import models.User;
import play.mvc.Controller;
import utils.JsonParsers;

import com.google.gson.JsonElement;

public class UsersAPI extends Controller
{
  public static void users()
  {
    List<User> users = User.findAll();
    renderJSON(JsonParsers.user2Json(users));
  }
  
  public static void user(String id)
  {
    User user = User.findById(id);  
    if (user == null)
    {
      notFound();
    }
    else
    {
      renderJSON(JsonParsers.user2Json(user));
    }
  }
  
  public static void createUser(JsonElement body)
  {
    User user = JsonParsers.json2User(body.toString());
    user.save();
    renderJSON(JsonParsers.user2Json(user));
  }
  
/*  public static void deleteUser(String id)
  {
    User user = User.findById(id);
    if (user == null)
    {
      notFound();
    }
    else
    {
      user.delete();
      renderText("success");
    }
  }*/
 
  public static void deleteUser(String id)
  {
    User user = User.findById(id);
    if (user == null)
    {
      notFound();
    }
    else
    {
      List<Residence> residences = user.residences;
      for(int j = 0; j < residences.size(); j += 1)
      {
        Residence res = Residence.findById(residences.get(j).uuid);
        user.residences.remove(res);
        user.save();
        res.delete();
      }
      user.delete();      
      renderText("success");
    }
  }
  
  public static void deleteAllUsers()
  {
    List<User> users = User.findAll();
    for(int i = 0; i < users.size(); i += 1)
    {
      User user = users.get(i);
      List<Residence> residences = user.residences;
      for(int j = 0; j < residences.size(); j += 1)
      {
        Residence res = Residence.findById(residences.get(j).uuid);
        user.residences.remove(res);
        user.save();
        res.delete();
      }
      user.delete();
    }
    renderText("success");
  }
}
