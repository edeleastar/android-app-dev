package models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import play.db.jpa.GenericModel;

@Entity
public class Residence extends GenericModel
{
  @Id
  @Column(name="id")
  public String  uuid           ;
  public String  geolocation    ;
  public String  datestamp      ;
  public boolean rented         ;
  public String  tenant         ;
  public double  zoom           ;
  public String  photoFileName  ;
  
  @ManyToOne
  public User user;

  public Residence(String uuid, String geolocation, String datestamp, boolean rented, String tenant, double zoom, String photoFileName)
  {                                      
    this.uuid            =     uuid            ;
    this.geolocation     =     geolocation     ;
    this.datestamp       =     datestamp       ;
    this.rented          =     rented          ;
    this.tenant          =     tenant          ;
    this.zoom            =     zoom            ;
    this.photoFileName   =     photoFileName   ;
  }
}
