package utils;

import java.util.ArrayList;
import java.util.List;

import models.Residence;
import models.User;
import flexjson.JSONDeserializer;
import flexjson.JSONSerializer;

public class JsonParsers
{
  public static JSONSerializer residenceSerializer = new JSONSerializer().exclude("class")
                                                                        .exclude("persistent")
                                                                        .exclude("entityId"); 
  
  public static JSONSerializer userSerializer       = new JSONSerializer().exclude("class")
                                                                        .exclude("persistent")
                                                                        .exclude("entityId")
                                                                        .exclude("residences");
  
  public static Residence json2Residence(String json)
  {
    return new JSONDeserializer<Residence>().deserialize(json, Residence.class); 
  }

  public static List<Residence> json2Residences(String json)
  {
    return new JSONDeserializer<ArrayList<Residence>>().use("values", Residence.class)
                                                  .deserialize(json);
  }
  
  public static String residence2Json(Object obj)
  {
    return residenceSerializer.serialize(obj);
  }
  
  public static List<Residence> residences2Json(String json)
  {
    return new JSONDeserializer<ArrayList<Residence>>().use("values", Residence.class)
                                                  .deserialize(json);
  } 

 
  public static User json2User(String json)
  {
  return new JSONDeserializer<User>().deserialize(json, User.class); 
  }
  
  public static List<User> json2Users(String json)
  {
  return new JSONDeserializer<ArrayList<User>>().use("values", User.class)
  .deserialize(json);
  }
  
  public static String user2Json(Object obj)
  {
  return userSerializer.serialize(obj);
  }
  
  public static List<User> users2Json(String json)
  {
  return new JSONDeserializer<ArrayList<User>>().use("values", User.class)
  .deserialize(json);
  } 
  
}