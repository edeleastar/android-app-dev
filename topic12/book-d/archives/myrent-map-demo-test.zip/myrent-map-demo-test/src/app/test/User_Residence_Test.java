package app.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import app.model.Residence;
import app.model.User;
import app.controllers.ResidenceAPI;
import app.controllers.UsersAPI;


public class User_Residence_Test
{
  User barney =  new User ("barney",  "gumble", "barney@gumble.com",  "secret");
  
  static User userArray [] = 
  { 
    new User ("homer",  "simpson", "homer@simpson.com",  "secret"),
    new User ("lisa",   "simpson", "lisa@simpson.com",   "secret"),
    new User ("maggie", "simpson", "maggie@simpson.com", "secret"),
    new User ("bart",   "simpson", "bart@simpson.com",   "secret"),
    new User ("marge",  "simpson", "marge@simpson.com",  "secret"),
  };  
  
  List <User> userList = new ArrayList<>();
  
  /**
   * Create list of users
   */
  @Before
  public void setup() throws Exception
  { 
    for (User user : userArray)
    {
      User returned = UsersAPI.createUser(user);
      userList.add(returned);
    }
    UsersAPI.createUser(barney);
  }
 
  @Test
  public void testCreateResidences () throws Exception
  {
    Residence res1 = new Residence ("a950cd66-f82c-427a-a5cb-4c005367017c", 
                                    "52,-7",
                                    "17-Nov-2014 12:45:53",                                    
                                    true,
                                    "A.N.Other",
                                    16.0,
                                    "filename");

    Residence res2 = new Residence ("c91375b3-562f-4492-9318-38da8e117b36", 
                                    "52,-7",
                                    "17-Nov-2014 12:45:53",                                    
                                    true,
                                    "A.N.Other",
                                    16.0,
                                    "filename");

    
    Residence res3 = new Residence ("d8435e57-9fd5-498a-95e1-e0481ad1e067", 
                                    "52,-7",
                                    "17-Nov-2014 12:45:53",                                    
                                    true,
                                    "A.N.Other",
                                    16.0,
                                    "filename");

    Residence returnedRes1 = ResidenceAPI.createResidence(barney, res1);
    Residence returnedRes2 = ResidenceAPI.createResidence(barney, res2);
    Residence returnedRes3 = ResidenceAPI.createResidence(barney, res3);
    
    assertEquals(res1, returnedRes1);
    assertEquals(res2, returnedRes2);
    assertEquals(res3, returnedRes3);

  }
  
  @After
  public void tearDown() throws Exception
  {
    UsersAPI.deleteAllUsers();
  }
}