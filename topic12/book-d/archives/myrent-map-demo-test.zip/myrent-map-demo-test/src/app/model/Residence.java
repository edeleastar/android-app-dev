package app.model;
import java.util.UUID;

import com.google.common.base.Objects;

import static com.google.common.base.Objects.toStringHelper;

public class Residence
{

  public String  uuid           ;
  public String  geolocation    ;
  public String  datestamp      ;
  public boolean rented         ;
  public String  tenant         ;
  public double  zoom           ;
  public String  photoFileName  ;
  
  
  public Residence(){}
  
  public Residence(String uuid, String geolocation, String datestamp, boolean rented, String tenant, double zoom, String photoFileName)
  {
    this.uuid            =     UUID.randomUUID().toString();
    this.geolocation     =     geolocation     ;
    this.datestamp        =    datestamp       ;
    this.rented          =     rented          ;
    this.tenant          =     tenant          ;
    this.zoom            =     zoom            ;
    this.photoFileName   =     photoFileName   ;
  }
  
  @Override
  public boolean equals(final Object obj)
  {
    if (obj instanceof Residence)
    {
      final Residence other = (Residence) obj;        
      return     Objects.equal(uuid           ,other.uuid)
              && Objects.equal(geolocation    ,other.geolocation)                          
              && Objects.equal(datestamp      ,other.datestamp)
              && Objects.equal(rented         ,other.rented)
              && Objects.equal(tenant         ,other.tenant)
              && Objects.equal(zoom           ,other.zoom)
              && Objects.equal(photoFileName  ,other.photoFileName);

    }
    else
    {
      return false;
    }
  }  

  @Override
  public String toString()
  {
    return toStringHelper(this).addValue(uuid)
                               .addValue(geolocation)
                               .addValue(datestamp)
                               .addValue(rented)
                               .addValue(zoom)
                               .addValue(photoFileName)
                               .toString();
  }
}
