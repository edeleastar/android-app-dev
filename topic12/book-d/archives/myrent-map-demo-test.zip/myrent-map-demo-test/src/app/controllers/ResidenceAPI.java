package app.controllers;

import java.util.List;

import app.api.Rest;
import app.model.JsonParsers;
import app.model.Residence;
import app.model.User;


public class ResidenceAPI
{ 
  public static List<Residence> getResidences(User user) throws Exception
  {
    String response =  Rest.get("/api/users/" + user.uuid + "/residences");
    List<Residence> donationList = JsonParsers.json2Residences(response);
    return donationList;
  }
  
  public static Residence createResidence(User user, Residence residence) throws Exception
  {
    //Routing: api/users/{userId}/residences   ResidencesAPI.createTweet
    String jsonRes = JsonParsers.residence2Json(residence);
    String response = Rest.post ("/api/users/" + user.uuid + "/residences", JsonParsers.residence2Json(residence));
    return JsonParsers.json2Residence(response);
  }
  
  public static void deleteResidence(User user, Residence residence) throws Exception
  {
    Rest.delete ("/api/users/" + user.uuid + "/residences/" + residence.uuid);
  } 
  
  public static void deleteAllResidences(User user) throws Exception
  {
    Rest.delete ("/api/users/" + user.uuid + "/residences");
  } 
}