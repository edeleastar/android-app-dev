package org.wit.myrent.activities;

import static org.wit.android.helpers.IntentHelper.navigateUp;
import static org.wit.android.helpers.IntentHelper.sendEmail;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.UUID;

import org.wit.android.helpers.ContactHelper;
import org.wit.myrent.R;
import org.wit.myrent.app.MyRentApp;
import org.wit.myrent.map.MapActivity;
import org.wit.myrent.models.Portfolio;
import org.wit.myrent.models.Residence;
import org.wit.myrent.models.User;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.DatePicker;
import android.widget.EditText;


public class ResidenceFragment extends Fragment implements TextWatcher, 
                                                        OnCheckedChangeListener, 
                                                        OnClickListener, 
                                                        DatePickerDialog.OnDateSetListener
{
  public static final String  EXTRA_RESIDENCE_ID      = "org.wit.myrent.RESIDENCE_ID";
  public static final String  EXTRA_NEW_RESIDENCE     = "org.wit.myrent.NEW_RESIDENCE";
  public static final String  EXTRA_LOCATION_FROM_MAP = "org.wit.myrent.EXTRA_LOCATION_FROM_MAP";
  public static final int     REQUEST_CONTACT         = 1;  
  public static final int     LOCATION_FROM_MAP       = 0;
  
  private EditText    geolocation;
  private CheckBox    rented;
  private Button      dateButton;
  private Button      tenantButton;
  private Button      reportButton;

  private Residence   residence;
  private Portfolio   portfolio;
  //private Button      mapButton;
  
  private User        user;
  private MyRentApp   app; 
  UUID                residenceId;  
  Boolean             isNewResidence;
  
  @Override
  public void onCreate(Bundle savedInstanceState)
  {
    super.onCreate(savedInstanceState);
    setHasOptionsMenu(true);

    residenceId = (UUID)getActivity().getIntent().getSerializableExtra(EXTRA_RESIDENCE_ID);
    app         = (MyRentApp) getActivity().getApplication();
    portfolio   = app.portfolio; 
    residence   = portfolio.getResidence(residenceId); 
    user        = app.logged_in_user;

    isNewResidence = (Boolean)getActivity().getIntent().getSerializableExtra(EXTRA_NEW_RESIDENCE);
  }

  @Override
  public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState)
  {
    View v = inflater.inflate(R.layout.fragment_residence, parent, false);

    getActivity().getActionBar().setDisplayHomeAsUpEnabled(true);
    addListeners(v);
    updateControls(residence);

    return v;
  } 
  
  private void addListeners(View v)
  {
    geolocation = (EditText) v.findViewById(R.id.geolocation);
    dateButton  = (Button)   v.findViewById(R.id.registration_date);
    rented      = (CheckBox) v.findViewById(R.id.isrented);
    tenantButton = (Button)  v.findViewById(R.id.tenant);
    reportButton = (Button)  v.findViewById(R.id.residence_reportButton);
    //mapButton    = (Button)  v.findViewById(R.id.show_map);

    geolocation .addTextChangedListener(this);
    dateButton  .setOnClickListener(this);
    rented      .setOnCheckedChangeListener(this);
    tenantButton.setOnClickListener(this);
    reportButton.setOnClickListener(this);
    //mapButton   .setOnClickListener(this);
  }

  public void updateControls(Residence residence)
  {
    geolocation.setText(residence.geolocation);   
    rented.setChecked(residence.rented);
    dateButton.setText(residence.getDateString());
  }

  @Override
  public void onCreateOptionsMenu(Menu menu, MenuInflater inflater)
  {
    super.onCreateOptionsMenu(menu, inflater);
    inflater.inflate(R.menu.residence_fragment, menu);
  }
  
  @Override
  public boolean onOptionsItemSelected(MenuItem item)
  {
    switch (item.getItemId())
    {
      case android.R.id.home: navigateUp(getActivity());
                              create_update_residence();
                              return true;
                              
      case R.id.launch_map  : Intent mapIntent = new Intent(getActivity(), MapActivity.class);
                              mapIntent.putExtra(EXTRA_RESIDENCE_ID, residence.getId());
                              mapIntent.putExtra("MarkersDraggable", true);
                              startActivity(mapIntent);
                              return true;
                              
      default               : return super.onOptionsItemSelected(item);
    }
  }


  /*
   * determine if a C(reate) or U(pdate) operation is in train and invoke appropriate method
   * use boolean flag to distinguish 
   */
  private void create_update_residence()
  {
    if(this.isNewResidence == true)
    {
      portfolio.createResidence(getActivity(), user, residence);
    }
    else
    {
      portfolio.updateResidence(getActivity(), user, residence);
    }
  }

  @Override
  public void onResume()
  {
    residence = portfolio.getResidence(residenceId); 
    updateControls(residence);
    super.onResume();
  }
  
  @Override
  public void onActivityResult(int requestCode, int resultCode, Intent data)
  {
    if (resultCode != Activity.RESULT_OK)
    {
      return;
    }
    switch(requestCode)
    {
      case REQUEST_CONTACT:
        String name = ContactHelper.getContact(getActivity(), data);
        residence.tenant = name;
        tenantButton.setText(name); 
        break;
     
    }
  }

  @Override
  public void beforeTextChanged(CharSequence s, int start, int count, int after)
  { }

  @Override
  public void onTextChanged(CharSequence s, int start, int before, int count)
  {}

  @Override
  public void afterTextChanged(Editable c)
  {
    Log.i(this.getClass().getSimpleName(), "geolocation " + c.toString());
    residence.geolocation = c.toString();    
  }

  @Override
  public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
  {
    residence.rented = isChecked;   
  }

  @Override
  public void onClick(View v)
  {
    switch (v.getId())
    {
      case R.id.registration_date      : Calendar c = Calendar.getInstance();
                                         DatePickerDialog dpd = new DatePickerDialog (getActivity(), this, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
                                         dpd.show();
                                         break; 
      case R.id.tenant                 : Intent i = new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);
                                         startActivityForResult(i, REQUEST_CONTACT);
                                         if (residence.tenant != null)
                                         {
                                           tenantButton.setText("Tenant: "+residence.tenant);
                                         }   
                                         break;
      case R.id.residence_reportButton : sendEmail(getActivity(), "", getString(R.string.residence_report_subject), residence.getResidenceReport(getActivity()));                           
                                         break;                      
/*      case R.id.show_map               : Intent mapIntent = new Intent(getActivity(), MapActivity.class);
                                         mapIntent.putExtra(EXTRA_RESIDENCE_ID, residence.getId());
                                         startActivity(mapIntent);
                                         break;*/
    }
  }

  @Override
  public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth)
  {
    Date date = new GregorianCalendar(year, monthOfYear, dayOfMonth).getTime();
    //residence.setDate(date);
    residence.datestamp = date.toString();
    dateButton.setText(residence.getDateString());
  }
}