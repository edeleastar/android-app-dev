package org.wit.myrent.models;

import static org.wit.android.helpers.LogHelpers.info;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.wit.myrent.controllers.ResidencesAPI;
import org.wit.myrent.http.Response;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

public class Portfolio implements Response<Residence>
{
  public  ArrayList<Residence>  residences;
  Context context;
  
  public Portfolio()
  {
    residences = new ArrayList<Residence>();

  }
  
  public void addResidence(Residence residence)
  {
    residences.add(residence);
  }

  public Residence getResidence(UUID id)
  {
    Log.i(this.getClass().getSimpleName(), "UUID parameter id: "+ id);

    for (Residence res : residences)
    {
      if(id.equals(res.getId()))
      {
        return res; 
      }
    }
    return null;
  }
  public void updateResidences(List<Residence> rxd)
  {
    residences.clear();
    residences.addAll(rxd);
   }
    
  private Residence updateResidence(Residence r)
  {
    for(int i = 0; i < residences.size(); i += 1)
    {
      Residence this_residence = residences.get(i);
      if(this_residence.getId().equals(r.getId()))
      {       
        this_residence.copy(r);//reinitialize with updated fields
        return this_residence;
      }
    }
    return r;
  }

  public void createResidence(Context context, User user, Residence residence)
  {
    ResidencesAPI.createResidence(context, this, "Saving residence", user, residence);
    this.context = context;//req for Toast
  }
  
  /*
   * To update an existing Residence instance:
   *    Delete existing
   *    Replace with modified
   */
  public void updateResidence(Context context, User user, Residence residence)
  {
    Residence r = updateResidence(residence);
    ResidencesAPI.updateResidence(context, this, "Updating residence", user, r);
    this.context = context;
  }
  
  public void deleteResidence(Context context, User user, Residence residence)
  {
    ResidencesAPI.deleteResidence(context, this, "Deleting residence", user, residence);
    //this.deleteResidence(residence);
    residences.remove(residence);
  }
  
  @Override
  public void setResponse(List<Residence> aList)
  {    
  }
  
  @Override
  public void setResponse(Residence residence)
  {
    if(context == null) return;
    if(residence != null)
    {
      if(residence.tenant.equals("deletion succeeded"))
          Toast.makeText(context, "deletion succeeded", Toast.LENGTH_SHORT);
      else
          Toast.makeText(context, "residence successfully saved", Toast.LENGTH_SHORT).show(); 
    }
    else
    {
      Toast.makeText(context, "failed to save/delete residence", Toast.LENGTH_SHORT).show(); 
    }
  }

  @Override
  public void errorOccurred(Exception e)
  {
    info(this, e.getLocalizedMessage());
  }
}