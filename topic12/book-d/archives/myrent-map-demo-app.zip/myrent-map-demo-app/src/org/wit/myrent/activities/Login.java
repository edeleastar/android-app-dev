package org.wit.myrent.activities;

import java.util.ArrayList;
import java.util.List;

import org.wit.myrent.R;
import org.wit.myrent.app.MyRentApp;
import org.wit.myrent.http.Response;
import org.wit.myrent.models.Residence;
import org.wit.myrent.models.User;
import org.wit.myrent.controllers.ResidencesAPI;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;


public class Login extends Activity implements Response<Residence>
{
  @Override
  protected void onCreate(Bundle savedInstanceState)
  {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_login);   
  }

  public void signinPressed (View view) 
  {
    MyRentApp app = (MyRentApp) getApplication();

    TextView email     = (TextView)  findViewById(R.id.loginEmail);
    TextView password  = (TextView)  findViewById(R.id.loginPassword);
    User user = app.validUser(email.getText().toString(), password.getText().toString());
    if (user != null)
    {
      ResidencesAPI.getResidences(this, this, user.firstName + " retrieving residences",user);
    }
    else
    {
      Toast toast = Toast.makeText(this, "invalid credentials", Toast.LENGTH_SHORT);
      toast.show();
    }
  }
  /**
   * Following 3 methods implementations required by Response<T> interface
   */
  @Override
  public void setResponse(List<Residence> aList)
  { 
    //residence list successfully retrieved from server
    MyRentApp app = (MyRentApp) getApplication();
    app.portfolio.updateResidences(aList);
    //app.portfolio.residences = (ArrayList<Residence>)aList;
    Toast.makeText(this, "residences retrieved", Toast.LENGTH_SHORT).show(); 
    startActivity (new Intent(this, ResidenceListActivity.class));
  }

  @Override
  public void setResponse(Residence anObject)
  {
  }

  @Override
  public void errorOccurred(Exception e)
  {
    //failed to retrieve residences
    Toast.makeText(this, "retrieval failed", Toast.LENGTH_LONG).show();    
  }
}