package org.wit.myrent.activities;

import java.util.List;

import org.wit.myrent.R;
import org.wit.myrent.app.MyRentApp;
import org.wit.myrent.controllers.UsersAPI;
import org.wit.myrent.http.Response;
import org.wit.myrent.models.User;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Welcome extends Activity implements Response<User>
{
  Button login;
  Button signup;
  
  @Override
  protected void onCreate(Bundle savedInstanceState)
  {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_welcome);
    
    login = (Button) findViewById(R.id.welcomeLogin);
    signup = (Button)findViewById(R.id.welcomeSignup);
    
    login.setEnabled(false);
    signup.setEnabled(false);
  }

  /**
   * Make the server call to retrieve residences in onResume
   */
  @Override
  protected void onResume()
  {
    UsersAPI.getUsers(this, this, "retrieving user list");
    super.onResume();
  }
  
  public void loginPressed (View view) 
  {
    startActivity (new Intent(this, Login.class));
  }

  public void signupPressed (View view) 
  {
    startActivity (new Intent(this, Signup.class));
  }

  @Override
  public void setResponse(List<User> users)
  {
    //users successfully retrieved from server
    MyRentApp app = (MyRentApp) getApplication();
    app.updateUserList(users);
    if(users.isEmpty())
    {
      Toast.makeText(this, "no registered users exist", Toast.LENGTH_SHORT).show();
      signup.setEnabled(true);
    }
    else
    {
      Toast.makeText(this, "user list retrieved", Toast.LENGTH_SHORT).show(); 
      login.setEnabled(true);
      signup.setEnabled(true);
    }
        
  }

  @Override
  public void setResponse(User anObject)
  {
  }

  @Override
  public void errorOccurred(Exception e)
  {
    Toast.makeText(this, "user retrieval failed", Toast.LENGTH_LONG).show();     
  }
 
}
