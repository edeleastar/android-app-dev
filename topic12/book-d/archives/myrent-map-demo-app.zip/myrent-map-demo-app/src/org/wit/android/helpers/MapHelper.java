package org.wit.android.helpers;

import android.content.Context;
import android.widget.Toast;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.gson.Gson;

public class MapHelper
{
  public static LatLng latLng(Context context, String geolocation)
  {
    String[] g = geolocation.split(",");
    try
    {
      if (g.length == 2)
      {
        return new LatLng(Double.parseDouble(g[0]), Double.parseDouble(g[1]));
      }
    }
    catch (NumberFormatException e)
    {
      LogHelpers.info(context, "Number format exception: invalid geolocation: " + e.getMessage());
    }
    Toast.makeText(context, "An invalid geolocation has been entered: defaulting to 0,0", Toast.LENGTH_SHORT).show();
    return new LatLng(0, 0);

  }

  
  public static LatLng latLng(String geolocation)
  {
    String[] g = geolocation.split(",");
    try
    {
      if (g.length == 2)
      {
        return new LatLng(Double.parseDouble(g[0]), Double.parseDouble(g[1]));
      }
    }
    catch (NumberFormatException e)
    {
       e.printStackTrace();
    }
    return new LatLng(0, 0);
  }
  
  public static String latLng(LatLng geo)
  {

    return String.format("%.6f", geo.latitude) + ", " + String.format("%.6f", geo.longitude);
  }
  
  /*
   * 
   *     marker = gmap.addMarker(new MarkerOptions()
                                .position(markerPosition)
                                .draggable(true)
                                .visible(true)
                                .alpha(0.7f)   
                                .title("residence origin")                          
                                .snippet("GPS : " + markerPosition.toString()));

   */
  /**
   * Tested ok
   * @param m
   * @return
   */
  public static String markerToJson(Marker m)
  {
    Gson gson = new Gson();
    String position = latLng(m.getPosition());
    String draggable = Boolean.toString(m.isDraggable());
    String visible  = Boolean.toString(m.isVisible());
    String alpha    = Float.toString(m.getAlpha());
    String title    = m.getTitle();    
    String snippet  = m.getSnippet();
    String[] s = {position,draggable,visible,alpha,title,snippet};
    return gson.toJson(s);
  }

  /**
   * Not tested
   * @param gmap
   * @param json
   * @return
   */
  public static Marker jsonToMarker(GoogleMap gmap, String json)
  {
    Gson gson = new Gson();
    String [] o  = gson.fromJson(json, String[].class);
    LatLng pos   = latLng(o[0]);
    boolean drag = Boolean.getBoolean(o[1]);
    boolean see  = Boolean.getBoolean(o[2]);
    float   alfa = Float.valueOf(o[3]);
    String  titl = o[4];
    String  msg  = o[5];
    
    
    MarkerOptions options = new MarkerOptions().position(pos)
                                               .draggable(drag)
                                               .visible(see)
                                               .alpha(alfa)
                                               .title(titl)
                                               .snippet(msg);
    Marker m = gmap.addMarker(options);
    return m;    
  }
}
