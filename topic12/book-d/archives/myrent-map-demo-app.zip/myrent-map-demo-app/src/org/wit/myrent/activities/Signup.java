package org.wit.myrent.activities;

import java.util.List;

import org.wit.myrent.R;
import org.wit.myrent.app.MyRentApp;
import org.wit.myrent.controllers.UsersAPI;
import org.wit.myrent.http.Response;
import org.wit.myrent.models.User;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;


public class Signup extends Activity implements Response<User>
{
  @Override
  protected void onCreate(Bundle savedInstanceState)
  {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_signup);
  }

  public void registerPressed (View view) 
  {
    TextView firstName = (TextView)  findViewById(R.id.firstName);
    TextView lastName  = (TextView)  findViewById(R.id.lastName);
    TextView email     = (TextView)  findViewById(R.id.Email);
    TextView password  = (TextView)  findViewById(R.id.Password);

    User user = new User (firstName.getText().toString(), lastName.getText().toString(), email.getText().toString(), password.getText().toString());
    
    MyRentApp app = (MyRentApp) getApplication();
    app.newUser(user);
    UsersAPI.createUser(this, this, "creating user", user);
    
  }

  @Override
  public void setResponse(List<User> aList)
  {
  }

  @Override
  public void setResponse(User user)
  {
    //user successfully added to database on server app
    MyRentApp app = (MyRentApp) getApplication();
    app.users.add(user);
    Toast.makeText(this, "successfully created new user", Toast.LENGTH_SHORT).show();   
    startActivity (new Intent(this, Login.class));
  }

  @Override
  public void errorOccurred(Exception e)
  {
    Toast.makeText(this, "failed to create new user", Toast.LENGTH_LONG).show();    
  }
}
