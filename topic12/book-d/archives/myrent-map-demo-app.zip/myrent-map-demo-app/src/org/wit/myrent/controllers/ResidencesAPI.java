package org.wit.myrent.controllers;


import java.util.List;

import org.wit.myrent.http.Request;
import org.wit.myrent.http.Response;
import org.wit.myrent.http.Rest;
import org.wit.myrent.httputils.JsonParsers;
import org.wit.myrent.models.Residence;
import org.wit.myrent.models.User;

import android.content.Context;

public class ResidencesAPI
{ 
  public static void getResidences(Context context, Response<Residence> response, String dialogMesssage, User user)
  {
    new GetResidences(context, response, dialogMesssage).execute(user);
  }

  public static void createResidence(Context context, Response<Residence> response, String dialogMesssage, User user, Residence residence)
  {
    new CreateResidence(context, response, dialogMesssage).execute(user,residence);
  }

  public static void updateResidence(Context context, Response<Residence> response, String dialogMesssage, User user, Residence residence)
  {
    new UpdateResidence(context, response, dialogMesssage).execute(user,residence);
  }
  
  public static void deleteResidence(Context context, Response<Residence> response, String dialogMesssage, User user, Residence residence)
  {
    new DeleteResidence(context, response, dialogMesssage).execute(user, residence);
  }
}

class GetResidences extends Request
{
  public GetResidences(Context context, Response<Residence> callback, String message)
  {
    super(context, callback, message);
  }

  @Override
  protected List<Residence> doRequest(Object... params) throws Exception
  {
    String userId = ((User)params[0]).uuid;
    String response =  Rest.get("/api/users/" + userId + "/residences");
    List<Residence> residenceList = JsonParsers.json2Residences(response);
    return residenceList;
  }
}

class CreateResidence extends Request
{
  public CreateResidence(Context context, Response<Residence> callback, String message)
  {
    super(context, callback, message);
  }

  @Override
  protected Residence doRequest(Object... params) throws Exception
  {
    User user           = (User)params[0];
    Residence residence = (Residence)params[1];
    String userId       = user.uuid;
    String resJson = JsonParsers.residence2Json(residence);
    String response = Rest.post ("/api/users/" + userId + "/residences", JsonParsers.residence2Json(residence));
    return JsonParsers.json2Residence(response);
  }
}

class UpdateResidence extends Request
{
  public UpdateResidence(Context context, Response<Residence> callback, String message)
  {
    super(context, callback, message);
  }

  @Override
  protected Residence doRequest(Object... params) throws Exception
  {
    User user           = (User)params[0];
    Residence residence = (Residence)params[1];
    String userId       = user.uuid;
    String response = Rest.put ("/api/users/" + userId + "/residences", JsonParsers.residence2Json(residence));
    return JsonParsers.json2Residence(response);
  }
}

class DeleteResidence extends Request 
{
  public DeleteResidence(Context context, Response<Residence> callback, String message)
  {
    super(context, callback, message);
  }

  @Override 
  protected Residence doRequest(Object... params) throws Exception

  {
    User user = ((User)params[0]);
    String residenceId = ((Residence)params[1]).getId().toString();
    String path    = "/api/users/" + user.uuid + "/residences/" + residenceId; 
    String response = Rest.delete (path);
    if(response.equals("success"))
    {
      Residence r = new Residence();
      r.tenant = "deletion succeeded";
      return r;//A hack: String not acceptable argument to any of Response methods
    }
    else
    {
      throw new Exception();
    }
  }
}

