package org.wit.myrent.app;

import java.util.ArrayList;
import java.util.List;

import org.wit.myrent.models.Portfolio;
import org.wit.myrent.models.Residence;
import org.wit.myrent.models.User;

import android.app.Application;

public class MyRentApp extends Application
{
  private static final String FILENAME = "portfolio.json";
  public Portfolio portfolio;
  public List <User> users = new ArrayList<User>();   
  public User logged_in_user;
  public Residence current_residence;
  
  @Override
  public void onCreate()
  {
    super.onCreate();
    portfolio = new Portfolio();
  }

  public void newUser(User user)
  {
    this.users.add(user);
  }
  
  public void updateUserList(List<User> users)
  {
    this.users.clear();
    this.users.addAll(users);
  }
  
  public User validUser (String email, String password)
  {
    for (User user : users)
    {
      if (user.email.equals(email) && user.password.equals(password))
      {
        logged_in_user = user;
        return user;
      }
    }
    return null;
  }  
}