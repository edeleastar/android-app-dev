package org.wit.myrent.models;

/**
 * @file    Residence.java
 * @author  jfitzgerald
 * @brief   Model class designed in this Android client compatible with corresponding Play server
 *          Uses flexJson annotations here (JSON) to ensure fields (and properties) match server
 *          Warning: getter methods (getXXXX()) unless annotated @JSON(include=false) will introduce
 *          a field XXXX into the json version of the model.
 *          flexJson 3.2 required for JSON annotations.
 * @link    http://flexjson.sourceforge.net/javadoc/index.html
 * @date    December 9th 2014
 * @version 1.0
 */
import java.util.Date;
import java.util.UUID;

import org.wit.android.helpers.MapHelper;
import org.wit.myrent.R;

//import flexjson.JSON;
import android.content.Context;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.Marker;

public class Residence
{

  private String  uuid;
  public  String  geolocation;
  public  String  datestamp;
  public  boolean rented;
  public  String  tenant;
  public  double  zoom; //zoom level of accompanying map
  public  String  photoFileName; //placeholder for compatibility with legacy myrent-service app
  
  
  public Residence()
  {
    uuid          = UUID.randomUUID().toString();
    geolocation   = "52.253456,-7.187162";
    datestamp     = new Date().toString();
    rented        = true;
    tenant        = "A.N.Other";
    zoom          = 16.0f;
    photoFileName = "photoFileName_placeholder";  
  }
 
  /**
   * Replaces the entire attribute list with that from Residence argument
   * @param r
   */
  public void copy(Residence r)
  {                                
    this.uuid          =   r.uuid         ;
    this.geolocation   =   r.geolocation  ;
    this.datestamp     =   r.datestamp    ;
    this.rented        =   r.rented       ;
    this.tenant        =   r.tenant       ;
    this.zoom          =   r.zoom         ;
    this.photoFileName =   r.photoFileName;
  }

  /**
   * This getter resolves to a json attribute named 'uuid'
   * This corresponds exactly with the service model name
   * @return
   */
  public String getUuid()
  {
    return uuid;
  }
  
  /**
   * To minimise code breakage during refactoring we return id as UUID type
   * Note that the String id is obtained from a UUID type
   * Hence we are allowed to convert back to the original UUID
   * Note the @JSON annotation: we do not wish this method to be interpreted as a json attribute
   * @return the String id converted to its UUID type
   */
  //@JSON(include=false)
  public UUID getId()
  {
    return UUID.fromString(uuid);
  }
  
  /**
   * 
   * @return the time-date stamp as a string
   */
  //@JSON(include=false)
  public String getDateString()
  {
    return datestamp;
  }


  //@JSON(include=false)
  public String getResidenceReport(Context context)
  {
    String rentedString = null;
    if (rented)
    {
      rentedString = context.getString(R.string.residence_report_rented);
    }
    else
    {
      rentedString = context.getString(R.string.residence_report_not_rented);
    }
    String prospectiveTenant = tenant;
    if (tenant == null)
    {
      prospectiveTenant = context.getString(R.string.residence_report_nobody_interested);
    }
    else
    {
      prospectiveTenant = context.getString(R.string.residence_report_prospective_tenant, tenant);
    }
    String report =  "Location " + geolocation + " Date: " + datestamp + " " + rentedString + " " + prospectiveTenant;
    return report;
  }
}



////////////////////obsolete code //////////////////////////////////////////
//import java.text.DateFormat;
//import java.text.ParseException;
//import java.util.TimeZone;

//@return formatted date string
//
/*  private String setDate()
{
  DateFormat df = DateFormat.getDateTimeInstance();
  df.setTimeZone(TimeZone.getTimeZone("UTC"));
  String formattedDate = df.format(new Date());
  return formattedDate;
}*/

/*  public Date getDate() throws ParseException
{
  DateFormat df = DateFormat.getDateTimeInstance();
  df.setTimeZone(TimeZone.getTimeZone("UTC"));
  return df.parse(datestamp);
}*/

//
//Sets the local datestamp using incoming Date
//@param date incoming Date object used to set datestamp
//
/*  public void setDate(Date date)
{
  DateFormat df = DateFormat.getDateTimeInstance();
  df.setTimeZone(TimeZone.getTimeZone("UTC"));
  this.datestamp = df.format(date);
}*/