package org.wit.myrent.httputils;

import java.lang.reflect.Type;
import java.util.List;

import org.wit.myrent.models.Residence;
import org.wit.myrent.models.User;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class JsonParsers
{
  static Gson gson = new Gson(); 
  //===================User=====================//
  public static User json2User(String json)
  {
    return gson.fromJson(json, User.class);   
  }
  
  public static List<User> json2Users(String json)
  {
    Type collectionType = new TypeToken<List<User>>() {}.getType();
    return gson.fromJson(json, collectionType); 
  }
  
  public static String user2Json(Object obj)
  {
    return gson.toJson(obj);
  } 
  
  //===============Residence========================//
  public static Residence json2Residence(String json)
  {
    return gson.fromJson(json, Residence.class);   
  }
  
  public static List<Residence> json2Residences(String json)
  {
    Type collectionType = new TypeToken<List<Residence>>() {}.getType();
    return gson.fromJson(json, collectionType); 
  }
  
  public static String residence2Json(Object obj)
  {
    return gson.toJson(obj);
  }
}