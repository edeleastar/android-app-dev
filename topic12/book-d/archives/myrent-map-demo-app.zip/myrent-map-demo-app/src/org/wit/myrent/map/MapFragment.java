package org.wit.myrent.map;


//import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import org.wit.android.helpers.MapHelper;
import org.wit.myrent.R;
import org.wit.myrent.activities.ResidenceFragment;
import org.wit.myrent.app.MyRentApp;
import org.wit.myrent.models.Portfolio;
import org.wit.myrent.models.Residence;

import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;


public class MapFragment extends SupportMapFragment implements  GoogleMap.OnMarkerDragListener,
                                                                GoogleMap.OnCameraChangeListener
                                                                
                                                                      
{
  private MyRentApp app;
  
  SupportMapFragment mapFragment;
  GoogleMap gmap;
  Marker marker;
  LatLng markerPosition;
  boolean markerDragged;
  Boolean dragFlag;//indicates if the markers may be dragged: value obtained from Intent.
  String currentGeolocation;// = "52.253456,-7.187162";
  
  private Residence   currentResidence;
  private Portfolio   portfolio;
  //List<Marker> markers  = new ArrayList<Marker>();//GoogleMap markers representing residence geolocations
  
  @Override
  public void onCreate(Bundle savedInstanceState)
  {
    super.onCreate(savedInstanceState);
    setHasOptionsMenu(true);
    
    UUID resId = (UUID)getActivity().getIntent().getSerializableExtra(ResidenceFragment.EXTRA_RESIDENCE_ID);
    dragFlag = (Boolean)getActivity().getIntent().getSerializableExtra("MarkersDraggable");

    app = (MyRentApp) getActivity().getApplication();
    portfolio = app.portfolio; 
    currentResidence = portfolio.getResidence(resId);
  }

  @Override
  public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState)
  {
    super.onCreateView(inflater, parent, savedInstanceState);
    View v = inflater.inflate(R.layout.fragment_map, parent, false);
    getActivity().getActionBar().setDisplayHomeAsUpEnabled(true);
    
    return v;
  }

  @Override
  public void onPause()
  {
    super.onPause();
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item)
  {
    switch (item.getItemId())
    {
    case android.R.id.home:
      getActivity().onBackPressed();
      return true;
    default:
      return super.onOptionsItemSelected(item);
    }
  }

  /* ====================== map ========================================== */
  private void initializeMapFragment()
  {
    FragmentManager fm = getChildFragmentManager();
    mapFragment = (SupportMapFragment) fm.findFragmentById(R.id.map);
    if (mapFragment == null)
    {
      mapFragment = SupportMapFragment.newInstance();
      fm.beginTransaction().replace(R.id.map, mapFragment).commit();
    }
  }

  @Override
  public void onMarkerDragStart(Marker arg0)
  {}
  
  @Override
  public void onMarkerDrag(Marker arg0)
  {}

  @Override
  public void onMarkerDragEnd(Marker arg0)
  {
    currentGeolocation = MapHelper.latLng(arg0.getPosition());
    getActivity().setTitle(currentGeolocation);
    currentResidence.geolocation = currentGeolocation;
    gmap.animateCamera(CameraUpdateFactory.newLatLng(arg0.getPosition()));
    markerDragged = true;
  }

  /*
   * this Camera refers to Google map, not device camera
   * When camera change equivalent to changed map position here
   * For example by panning map to new position
   * Method does the following:
   *      saves zoom position to model layer
   *      removes existing non-null marker
   *      creates and positions new marker to residence geolocation
   * Marker draggable attribute set by flag dragFlag
   */
  @Override
  public void onCameraChange(CameraPosition arg0)
  {
    currentResidence.zoom = arg0.zoom;
    markerPosition = MapHelper.latLng(getActivity(), currentGeolocation);
    if (marker != null)
    {
      marker.remove();
    }

    marker = gmap.addMarker(new MarkerOptions()
                                .position(markerPosition)
                                .draggable(dragFlag)
                                .visible(true)
                                .title("residence origin")
                                .alpha(0.7f)
                                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE))
                                .snippet("GPS : " + markerPosition.toString()));
    addVisibleRegionMarkers();

  }
  /*
   * initializes and renders the map
   * sets map type, example HYBRID in this case
   * sets the drag marker listener (but does not create a marker)
   * sets the map (camera) changed listener
   */
  private void renderMap(LatLng markerPosition)
  {
    if (mapFragment != null)
    {
      gmap = mapFragment.getMap();
      if (gmap != null)
      {
        gmap.animateCamera(CameraUpdateFactory.newLatLngZoom(markerPosition, (float)currentResidence.zoom));
        gmap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
        gmap.setOnMarkerDragListener(this);
        gmap.setOnCameraChangeListener(this);//this Camera refers to Google map, not device camera
      }
    }
  }

  /* @see http://stackoverflow.com/questions/18206615/how-to-use-google-map-v2-inside-fragment 
   * Necessary to wait until MapFragment created before initializing map fragment
   * Note that map fragment is nested within residence fragment. See the xml layout file for residence frag
  */

  @Override
  public void onActivityCreated(Bundle savedInstanceState)
  {
    super.onActivityCreated(savedInstanceState);
    currentGeolocation = currentResidence.geolocation;
    initializeMapFragment();  
  }

@Override
  public void onStart()
  {
    super.onStart();
    renderMap(MapHelper.latLng(getActivity(), currentGeolocation));
  }

  /**
   * add a marker to map corresponding to location of arg res
   * markers set non-draggable
   * @param the Residence object for which marker added to map
   */
  public void addMarker(Residence res)
  {
    LatLng pos = MapHelper.latLng(res.geolocation);
    MarkerOptions options = new MarkerOptions().position(pos)
                                               .draggable(false)
                                               .visible(true)
                                               .alpha(0.7f)
                                               .title("Residence Location")
                                               .snippet("GPS : " + res.geolocation);
     gmap.addMarker(options);
  }

  /**
   * Add markers within visible region (that is the visible screen)
   */
  public void addVisibleRegionMarkers()
  {
    LatLngBounds bounds = gmap.getProjection().getVisibleRegion().latLngBounds;

    List<Residence> residences = portfolio.residences;
    Iterator<Residence> it = residences.iterator();
    while(it.hasNext())
    { 
      Residence r = it.next();
      LatLng markerPoint = MapHelper.latLng(r.geolocation);
      //include points within visible region not including current residence
      if(bounds.contains(markerPoint) && !r.getUuid().equals(currentResidence.getUuid()))
      {
          addMarker(r);    
      } 
    }
  }
  
}