package org.wit.myrent.services;

import java.util.ArrayList;
import java.util.List;

import org.wit.android.helpers.LogHelpers;
import org.wit.myrent.activities.ResidenceListFragment;
import org.wit.myrent.app.MyRentApp;
import org.wit.myrent.http.Rest;
import org.wit.myrent.httputils.JsonParsers;
import org.wit.myrent.models.Portfolio;
import org.wit.myrent.models.Residence;

import android.app.IntentService;
import android.content.Intent;
import android.support.v4.content.LocalBroadcastManager;

public class RefreshService extends IntentService
{

  public RefreshService()
  {
    super("RefreshService");
  }

  @Override
  public void onCreate()
  {
    super.onCreate();
    LogHelpers.info(this, "onCreated");
  }
  
  /*
   * invoked on worker thread(non-Javadoc)
   * @see android.app.IntentService#onHandleIntent(android.content.Intent)
   */
  @Override
  protected void onHandleIntent(Intent intent)
  {
    MyRentApp app = (MyRentApp)getApplication();
    Portfolio portfolio = app.portfolio;
    try
    {
      String response =  Rest.get("/api/users/" + app.logged_in_user.uuid + "/residences");
      List<Residence> residenceList = JsonParsers.json2Residences(response);
      portfolio.updateResidences(residenceList);
      LogHelpers.info(this, "Residence list received");
      broadcastIntent();
    }
    catch(Exception e)
    {
      LogHelpers.info(this, "failed to retrieve residences : " + e.getMessage());      
    }    
  }
  private void broadcastIntent()
  {
    Intent localIntent = new Intent(ResidenceListFragment.BROADCAST_ACTION);
    // Broadcasts the Intent to receivers in this app.
    LocalBroadcastManager.getInstance(this).sendBroadcast(localIntent);
  }
  
  @Override
  public void onDestroy()
  {
    super.onDestroy();
    LogHelpers.info(this, "service destroyed");
  }
}