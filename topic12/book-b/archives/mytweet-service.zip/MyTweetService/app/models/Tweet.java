package models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import play.db.jpa.GenericModel;

@Entity
public class Tweet extends GenericModel
{
  @Id
  @Column(name="id")
  public String uuid;
  public String message;
  public String datestamp;
  @ManyToOne
  public User user;

  public Tweet(String uuid, String message, String datestamp)
  {
    this.uuid       = uuid;
    this.message    = message;
    this.datestamp  = datestamp;
  }
}
