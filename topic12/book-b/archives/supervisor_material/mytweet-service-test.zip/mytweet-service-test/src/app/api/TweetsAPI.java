package app.api;

import java.util.List;
import app.model.Tweet;
import app.model.User;


public class TweetsAPI
{ 
  //============================User============================================
  public static List<User> getUsers() throws Exception
  {
    String response =  Rest.get("/api/users");
    List<User> userList = JsonParsers.json2Users(response);
    return userList;
  }
  
  public static User getUser(Long uuid) throws Exception
  {
    String response =  Rest.get("/api/users/" + uuid);
    User user = JsonParsers.json2User(response);
    return user;
  }
  
  public static User createUser(User user) throws Exception
  {
    String response = Rest.post ("/api/users", JsonParsers.user2Json(user));
    return JsonParsers.json2User(response);
  }
  
  public static void deleteUser(User user) throws Exception
  {
    Rest.delete ("/api/users/" + user.uuid);
  }    
  //=========================Tweet============================================
  public static List<Tweet> getTweets(User user) throws Exception
  {
    String response =  Rest.get("/api/users/" + user.uuid + "/tweets");
    List<Tweet> donationList = JsonParsers.json2Tweets(response);
    return donationList;
  }
  
  public static Tweet createTweet(User user, Tweet tweet) throws Exception
  {
    //Routing: api/users/{userId}/tweets   TweetsAPI.createTweet
    String response = Rest.post ("/api/users/" + user.uuid + "/tweets", JsonParsers.tweet2Json(tweet));
    return JsonParsers.json2Tweet(response);
  }
  
  public static void deleteTweet(User user, Tweet tweet) throws Exception
  {
    Rest.delete ("/api/users/" + user.uuid + "/tweets/" + tweet.uuid);
  } 
  
  public static void deleteAllTweets(User user) throws Exception
  {
    Rest.delete ("/api/users/" + user.uuid + "/tweets");
  } 
}