package controllers;

import java.util.List;
import java.util.Random;

import models.Tweet;
import models.User;
import play.Logger;
import play.mvc.Controller;
import utils.JsonParsers; 

import com.google.gson.JsonElement;

public class TweetsAPI extends Controller
{
  /**
   * retrieve all tweets
   */
  public static void tweets(String userId)
  {
    User user = User.findById(userId);
    //List<Tweet> tweets = Tweet.findAll();
    List<Tweet> tweets = user.tweets;
    renderJSON(JsonParsers.tweet2Json(tweets));
  }
  
  public static void tweet(String id)
  {
    Tweet tweet = Tweet.findById(id);  
    if (tweet == null)
    {
      notFound();
    }
    else
    {
      renderJSON(JsonParsers.tweet2Json(tweet));
    }
  }
  
  public static void createTweet(String userId, JsonElement body)
  {
    Tweet tweet = JsonParsers.json2Tweet(body.toString());
    User user = User.findById(userId);
	tweet.user = user;
    tweet.save();
    renderJSON(JsonParsers.tweet2Json(tweet));
  }
  
  public static void deleteTweet(String id)
  {
    Tweet tweet = Tweet.findById(id);
    if (tweet == null)
    {
      notFound();
    }
    else
    {
      tweet.delete();
      renderText("success");
    }
  }
  
  public static void deleteAllTweets()
  {
    Tweet.deleteAll();
    renderText("success");
  }  

}