package org.wit.mytweet.activities;

import java.util.List;

import org.wit.mytweet.R;
import org.wit.mytweet.app.MyTweetApp;
import org.wit.mytweet.http.Response;
import org.wit.mytweet.model.User;
import org.wit.mytweets.controllers.UsersAPI;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class WelcomeActivity extends Activity implements Response<User>
{
  Button login;
  Button signup;
  
  @Override
  protected void onCreate(Bundle savedInstanceState)
  {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_welcome);
    
    login = (Button) findViewById(R.id.welcomeLogin);
    signup = (Button)findViewById(R.id.welcomeSignup);
    
    login.setEnabled(false);
    signup.setEnabled(false);
    
    //UsersAPI.getUsers(this, this, "retrieving user list");
  }

  /**
   * Make the server call to retrieve tweets in onResume
   */
  @Override
  protected void onResume()
  {
    //TweetsAPI.getTweets(this, this, "retrieving tweets");
    UsersAPI.getUsers(this, this, "retrieving user list");
    super.onResume();
  }
  
  public void loginPressed (View view) 
  {
    startActivity (new Intent(this, Login.class));
  }

  public void signupPressed (View view) 
  {
    startActivity (new Intent(this, Signup.class));
  }

  @Override
  public void setResponse(List<User> users)
  {
    //tweets successfully retrieved from server
    MyTweetApp app = (MyTweetApp) getApplication();
    app.updateUserList(users);
    if(users.isEmpty())
    {
      Toast.makeText(this, "no registered users exist", Toast.LENGTH_SHORT).show();
      signup.setEnabled(true);
    }
    else
    {
      Toast.makeText(this, "user list retrieved", Toast.LENGTH_SHORT).show(); 
      login.setEnabled(true);
      signup.setEnabled(true);
    }
        
  }

  @Override
  public void setResponse(User anObject)
  {
    // TODO Auto-generated method stub
    
  }

  @Override
  public void errorOccurred(Exception e)
  {
    Toast.makeText(this, "user retrieval failed", Toast.LENGTH_LONG).show();     
  }
 
}
