package org.wit.mytweets.controllers;

import java.util.List;

import org.wit.mytweet.http.Request;
import org.wit.mytweet.http.Response;
import org.wit.mytweet.http.Rest;
import org.wit.mytweet.httputils.JsonParsers;
import org.wit.mytweet.model.User;

import android.content.Context;

public class UsersAPI
{ 
  public static void getUsers(Context context, Response<User> response, String dialogMesssage)
  {
    new GetUsers(context, response, dialogMesssage).execute();
  }
  
  public static void createUser(Context context, Response<User> response, String dialogMesssage, User user)
  {
    new CreateUser(context, response, dialogMesssage).execute(user);
  }
  
  public static void deleteUser(Context context, Response<User> response, String dialogMesssage, User user)
  {
    new DeleteUser(context, response, dialogMesssage).execute(user);
  }
}
//===============================================================================================================//
class GetUsers extends Request
{
  public GetUsers(Context context, Response<User> callback, String message)
  {
    super(context, callback, message);
  }

  @Override
  protected List<User> doRequest(Object... params) throws Exception
  {
    String response =  Rest.get("/api/users");
    List<User> userList = JsonParsers.json2Users(response);
    return userList;
  }
}
 
class CreateUser extends Request
{
  public CreateUser(Context context, Response<User> callback, String message)
  {
    super(context, callback, message);
  }

  @Override
  protected User doRequest(Object... params) throws Exception
  {
    String response = Rest.post ("/api/users", JsonParsers.user2Json(params[0]));
    return JsonParsers.json2User(response);
  }
}

class DeleteUser extends Request 
{
  public DeleteUser(Context context, Response<User> callback, String message)
  {
    super(context, callback, message);
  }
  
  @Override 
  protected User doRequest(Object... params) throws Exception

  {
    String id = ((User)params[0]).uuid.toString();
    String path = "/api/users/" + id; 
    String response = Rest.delete (path);
    if(response.equals("success"))
    {
      return new User();
    }
    else
    {
      throw new Exception();
    }
  }
}
