package org.wit.mytweet.model;

import java.text.DateFormat;
import java.util.Date;
import java.util.TimeZone;
import java.util.UUID;

import org.json.JSONException;
import org.json.JSONObject;

public class Tweet
{
  /**
   * We have changed fields Date and UUID for ease of use in http
   * We could have allowed the service to generate the id as is usual practice
   * However it's more convenient to do so when the Tweet instance is first created
   * Otherwise a blocking http call would be required required in the Tweet constructor below
   * The id is required immediately in the application
   * We send to id the server in the http call and configure the server to allow this practice
   */
  private  String uuid; //mandates use of getter method getId()
  public   String message;
  private  String datestamp; //mandates use of getter method getDateString()
  private  User   user;

  private static final String JSON_UUID   = "uuid";
  private static final String JSON_TWEET  = "message";
  private static final String JSON_DATE   = "datestamp";

  
  public Tweet(User user)
  {
    uuid = UUID.randomUUID().toString();
    datestamp = setDate();
    message = "";
    this.user = user;
  }
  public Tweet(JSONObject json) throws JSONException
  {
    uuid       = json.getString(JSON_UUID);
    message    = json.getString(JSON_TWEET);
    datestamp  = json.getString(JSON_DATE);
  }

  public JSONObject toJSON() throws JSONException
  {
    JSONObject json = new JSONObject();
    json.put(JSON_UUID,   uuid);
    json.put(JSON_TWEET,  message);
    json.put(JSON_DATE,   datestamp);
    return json;
  }

  /**
   * To minimise code breakage we return id as UUID type
   * Note that the String id is obtained from a UUID type
   * Hence we are allowed to convert back to the original UUID
   * 
   * @return the String id converted to its UUID type
   */
  public UUID getId()
  {
    return UUID.fromString(uuid);
  }
  
  /**
   * Retaining this method which was previously used (before refactoring) 
   * 
   * @return
   */
  public String getDateString()
  {
    return datestamp;
  }

  /**
   * 
   * @return formatted date string
   */
  private String setDate()
  {
    DateFormat df = DateFormat.getDateTimeInstance();
    df.setTimeZone(TimeZone.getTimeZone("UTC"));
    String formattedDate = df.format(new Date());
    return formattedDate;
  }
  
  public String getUserId()
  {
    return user.uuid;
  }
}
