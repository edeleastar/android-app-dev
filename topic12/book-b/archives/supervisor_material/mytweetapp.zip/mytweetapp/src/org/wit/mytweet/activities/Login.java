package org.wit.mytweet.activities;

import java.util.List;

import org.wit.mytweet.R;
import org.wit.mytweet.app.MyTweetApp;
import org.wit.mytweet.http.Response;
import org.wit.mytweet.model.Tweet;
import org.wit.mytweet.model.User;
import org.wit.mytweets.controllers.TweetsAPI;
import org.wit.mytweets.controllers.UsersAPI;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;


public class Login extends Activity implements Response<Tweet>
{
  @Override
  protected void onCreate(Bundle savedInstanceState)
  {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_login);   
  }

  public void signinPressed (View view) 
  {
    MyTweetApp app = (MyTweetApp) getApplication();

    TextView email     = (TextView)  findViewById(R.id.loginEmail);
    TextView password  = (TextView)  findViewById(R.id.loginPassword);
    User user = app.validUser(email.getText().toString(), password.getText().toString());
    if (user != null)
    {
      TweetsAPI.getTweets(this, this, user.firstName + " retrieving tweets",user);
    }
    else
    {
      Toast toast = Toast.makeText(this, "invalid credentials", Toast.LENGTH_SHORT);
      toast.show();
    }
  }
  /**
   * Following 3 methods implementations required by Response<T> interface
   */
  @Override
  public void setResponse(List<Tweet> aList)
  { 
    //tweets successfully retrieved from server
    MyTweetApp app = (MyTweetApp) getApplication();
    app.tweetlist.updateTweets(aList);
    Toast.makeText(this, "tweets retrieved", Toast.LENGTH_SHORT).show(); 
    startActivity (new Intent(this, TimeLineActivity.class));
  }

  @Override
  public void setResponse(Tweet anObject)
  {
  }

  @Override
  public void errorOccurred(Exception e)
  {
    //failed to retrieve tweets
    Toast.makeText(this, "retrieval failed", Toast.LENGTH_LONG).show();    
  }
/*  @Override
  public void setResponse(List<User> aList)
  {
    MyTweetApp app = (MyTweetApp) getApplication();
    app.users = aList;
    
  }

  @Override
  public void setResponse(User anObject)
  {
    // TODO Auto-generated method stub
    
  }

  @Override
  public void errorOccurred(Exception e)
  {
    Toast toast = Toast.makeText(this, "MyTweet service unavailable.\nUnknown network problem", Toast.LENGTH_LONG);
    toast.show();
    startActivity (new Intent(this, WelcomeActivity.class));
    
  }*/
}