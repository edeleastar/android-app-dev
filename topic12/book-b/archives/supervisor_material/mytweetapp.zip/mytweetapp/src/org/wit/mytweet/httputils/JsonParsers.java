package org.wit.mytweet.httputils;

import java.lang.reflect.Type;
import java.util.List;

import org.wit.mytweet.model.Tweet;
import org.wit.mytweet.model.User;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class JsonParsers
{
  static Gson gson = new Gson(); 
  //===================User=====================//
  public static User json2User(String json)
  {
    return gson.fromJson(json, User.class);   
  }
  
  public static List<User> json2Users(String json)
  {
    Type collectionType = new TypeToken<List<User>>() {}.getType();
    return gson.fromJson(json, collectionType); 
  }
  
  public static String user2Json(Object obj)
  {
    return gson.toJson(obj);
  } 
  
  //===============Tweet========================//
  public static Tweet json2Tweet(String json)
  {
    return gson.fromJson(json, Tweet.class);   
  }
  
  public static List<Tweet> json2Tweets(String json)
  {
    Type collectionType = new TypeToken<List<Tweet>>() {}.getType();
    return gson.fromJson(json, collectionType); 
  }
  
  public static String tweet2Json(Object obj)
  {
    return gson.toJson(obj);
  }
}