package org.wit.mytweet.app;

import static org.wit.android.helpers.LogHelpers.info;

import java.util.ArrayList;
import java.util.List;

import org.wit.mytweet.model.TweetList;
import org.wit.mytweet.model.TweetListSerializer;
import org.wit.mytweet.model.User;

import android.app.Application;

public class MyTweetApp extends Application
{
  private static final String FILENAME = "tweetlist.json";
  public TweetList tweetlist;  
  public List <User> users = new ArrayList<User>();   
  public User logged_in_user;

  public void onCreate()
  {
    super.onCreate();
    TweetListSerializer serializer = new TweetListSerializer(this, FILENAME);
    tweetlist = new TweetList(serializer);

    info(this, "TweetControl app launched");
  }
  
  public void updateUserList(List<User> users)
  {
    this.users.clear();
    this.users.addAll(users);
  }
  
  public void newUser(User user)
  {
    this.users.add(user);
  }
  
  public User validUser (String email, String password)
  {
    for (User user : users)
    {
      if (user.email.equals(email) && user.password.equals(password))
      {
        logged_in_user = user;
        return user;
      }
    }
    return null;
  }
}
