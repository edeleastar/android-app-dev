package org.wit.mytweets.controllers;

import java.util.List;

import org.wit.mytweet.http.Request;
import org.wit.mytweet.http.Response;
import org.wit.mytweet.http.Rest;
import org.wit.mytweet.httputils.JsonParsers;
import org.wit.mytweet.model.Tweet;
import org.wit.mytweet.model.User;

import android.content.Context;

public class TweetsAPI
{ 
  public static void getTweets(Context context, Response<Tweet> response, String dialogMesssage, User user)
  {
    new GetTweets(context, response, dialogMesssage).execute(user);
  }
  
  public static void createTweet(Context context, Response<Tweet> response, String dialogMesssage, User user, Tweet tweet)
  {
    new CreateTweet(context, response, dialogMesssage).execute(user,tweet);
  }
  
  public static void deleteTweet(Context context, Response<Tweet> response, String dialogMesssage, User user, Tweet tweet)
  {
    new DeleteTweet(context, response, dialogMesssage).execute(user, tweet);
  }
}
 
class GetTweets extends Request
{
  public GetTweets(Context context, Response<Tweet> callback, String message)
  {
    super(context, callback, message);
  }

  @Override
  protected List<Tweet> doRequest(Object... params) throws Exception
  {
    String userId = ((User)params[0]).uuid;
    String response =  Rest.get("/api/users/" + userId + "/tweets");
    List<Tweet> tweetList = JsonParsers.json2Tweets(response);
    return tweetList;
  }
}

class CreateTweet extends Request
{
  public CreateTweet(Context context, Response<Tweet> callback, String message)
  {
    super(context, callback, message);
  }

  @Override
  protected Tweet doRequest(Object... params) throws Exception
  {
    String userId = ((User)params[0]).uuid;
    String response = Rest.post ("/api/users/" + userId + "/tweets", JsonParsers.tweet2Json(params[1]));
    return JsonParsers.json2Tweet(response);
  }
}

class DeleteTweet extends Request 
{
  public DeleteTweet(Context context, Response<Tweet> callback, String message)
  {
    super(context, callback, message);
  }
  
  @Override 
  protected Tweet doRequest(Object... params) throws Exception

  {
	User user = ((User)params[0]);
    String tweetId = ((Tweet)params[1]).getId().toString();
    String path    = "/api/users/" + user.uuid + "/tweets/" + tweetId; 
    String response = Rest.delete (path);
    if(response.equals("success"))
    {
      return new Tweet(user);//String not acceptable argument to any of Response methods so we fake it
    }
    else
    {
      throw new Exception();
    }
  }
}
