package org.wit.mytweet.activities;

import java.util.List;

import org.wit.mytweet.R;
import org.wit.mytweet.app.MyTweetApp;
import org.wit.mytweet.http.Response;
import org.wit.mytweet.model.User;
import org.wit.mytweets.controllers.UsersAPI;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;


public class Signup extends Activity implements Response<User>
{
  @Override
  protected void onCreate(Bundle savedInstanceState)
  {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_signup);
  }

  public void registerPressed (View view) 
  {
    TextView firstName = (TextView)  findViewById(R.id.firstName);
    TextView lastName  = (TextView)  findViewById(R.id.lastName);
    TextView email     = (TextView)  findViewById(R.id.Email);
    TextView password  = (TextView)  findViewById(R.id.Password);

    User user = new User (firstName.getText().toString(), lastName.getText().toString(), email.getText().toString(), password.getText().toString());
    
    MyTweetApp app = (MyTweetApp) getApplication();
    app.newUser(user);
    UsersAPI.createUser(this, this, "creating user", user);
    
  }

  @Override
  public void setResponse(List<User> aList)
  {
  }

  @Override
  public void setResponse(User user)
  {
    //user successfully added to database on server app
    MyTweetApp app = (MyTweetApp) getApplication();
    app.users.add(user);
    Toast.makeText(this, "successfully created new user", Toast.LENGTH_SHORT).show();   
    startActivity (new Intent(this, Login.class));
  }

  @Override
  public void errorOccurred(Exception e)
  {
    Toast.makeText(this, "failed to create new user", Toast.LENGTH_LONG).show();    
  }
}
