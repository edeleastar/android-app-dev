package app.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import app.controllers.TweetsAPI;
import app.controllers.UsersAPI;
import app.model.Tweet;
import app.model.User;


public class TweetTest
{
  User marge =  new User ("marge",  "simpson", "homer@simpson.com",  "secret");
  
  @Before
  public void setup() throws Exception
  { 
    marge = UsersAPI.createUser(marge);
  }
  
  @After
  public void teardown() throws Exception
  {
    UsersAPI.deleteUser(marge);
  }
  
  @Test
  public void testCreateTweet () throws Exception
  {
    Tweet tweet = new Tweet ("cash", "17-Nov-2014 12:45:53");
    Tweet returnedTweet = TweetsAPI.createTweet(marge, tweet);
    assertEquals (tweet, returnedTweet);
    
    TweetsAPI.deleteTweet(marge, returnedTweet);
  }
  
  
  @Test
  public void testCreateTweets () throws Exception
  {
    Tweet tweet1 = new Tweet ("cash", "17-Nov-2014 12:45:53");
    Tweet tweet2 = new Tweet ("cash", "17-Nov-2014 12:45:53");
    Tweet tweet3 = new Tweet ("paypal", "17-Nov-2014 12:45:53");
    
    Tweet returnedTweet1 = TweetsAPI.createTweet(marge, tweet1);
    Tweet returnedTweet2 = TweetsAPI.createTweet(marge, tweet2);
    Tweet returnedTweet3 = TweetsAPI.createTweet(marge, tweet3);
    
    assertEquals(tweet1, returnedTweet1);
    assertEquals(tweet2, returnedTweet2);
    assertEquals(tweet3, returnedTweet3);

    TweetsAPI.deleteTweet(marge, returnedTweet1);
    TweetsAPI.deleteTweet(marge, returnedTweet2);    
    TweetsAPI.deleteTweet(marge, returnedTweet3);
  }
  
  @Test
  public void testListTweets () throws Exception
  {
    Tweet tweet1 = new Tweet ("cash", "17-Nov-2014 12:45:53");
    Tweet tweet2 = new Tweet ("cash", "17-Nov-2014 12:45:53");
    Tweet tweet3 = new Tweet ("paypal", "17-Nov-2014 12:45:53");
    
    tweet1.user = marge;
    tweet2.user = marge;
    tweet3.user = marge;
    
    TweetsAPI.createTweet(marge, tweet1);
    TweetsAPI.createTweet(marge, tweet2);
    TweetsAPI.createTweet(marge, tweet3);
    
    List<Tweet> tweets = TweetsAPI.getTweets(marge);
    assertEquals (3, tweets.size());
    
    assertTrue(tweets.contains(tweet1));
    assertTrue(tweets.contains(tweet2));
    assertTrue(tweets.contains(tweet3));

    TweetsAPI.deleteTweet(marge, tweets.get(0));
    TweetsAPI.deleteTweet(marge, tweets.get(1));    
    TweetsAPI.deleteTweet(marge, tweets.get(2));
  }
  
}
