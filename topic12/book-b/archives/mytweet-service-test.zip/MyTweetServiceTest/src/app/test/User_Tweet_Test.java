package app.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import app.model.Tweet;
import app.model.User;
import app.controllers.TweetsAPI;
import app.controllers.UsersAPI;


public class User_Tweet_Test
{
  User barney =  new User ("barney",  "gumble", "barney@gumble.com",  "secret");
  
  static User userArray [] = 
  { 
    new User ("homer",  "simpson", "homer@simpson.com",  "secret"),
    new User ("lisa",   "simpson", "lisa@simpson.com",   "secret"),
    new User ("maggie", "simpson", "maggie@simpson.com", "secret"),
    new User ("bart",   "simpson", "bart@simpson.com",   "secret"),
    new User ("marge",  "simpson", "marge@simpson.com",  "secret"),
  };  
  
  List <User> userList = new ArrayList<>();
  
  /**
   * Create list of users
   */
  @Before
  public void setup() throws Exception
  { 
    for (User user : userArray)
    {
      User returned = UsersAPI.createUser(user);
      userList.add(returned);
    }
    UsersAPI.createUser(barney);
  }
 
  @Test
  public void testCreateTweets () throws Exception
  {
    Tweet tweet1 = new Tweet ("cash", "17-Nov-2014 12:45:53");
    Tweet tweet2 = new Tweet ("cash", "17-Nov-2014 12:45:53");
    Tweet tweet3 = new Tweet ("paypal", "17-Nov-2014 12:45:53");
    
    Tweet returnedTweet1 = TweetsAPI.createTweet(barney, tweet1);
    Tweet returnedTweet2 = TweetsAPI.createTweet(barney, tweet2);
    Tweet returnedTweet3 = TweetsAPI.createTweet(barney, tweet3);
    
    assertEquals(tweet1, returnedTweet1);
    assertEquals(tweet2, returnedTweet2);
    assertEquals(tweet3, returnedTweet3);
  }
  //@After
  public void tearDown() throws Exception
  {
	  UsersAPI.deleteAllUsers();
  }
}