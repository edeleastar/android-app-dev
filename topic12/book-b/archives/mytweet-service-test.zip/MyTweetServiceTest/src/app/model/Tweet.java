package app.model;
import java.util.UUID;

import com.google.common.base.Objects;

import static com.google.common.base.Objects.toStringHelper;

public class Tweet
{

  public String uuid;
  public String message;
  public String datestamp;
  
  public User   user;
  
  public Tweet(){}
  
  public Tweet(String message, String datestamp)
  {
    this.uuid       = UUID.randomUUID().toString();
    this.message    = message;
    this.datestamp  = datestamp;
  }
  
  @Override
  public boolean equals(final Object obj)
  {
    if (obj instanceof Tweet)
    {
      final Tweet other = (Tweet) obj;        
      return     Objects.equal(message,   other.message)
              && Objects.equal(datestamp, other.datestamp)  ;                          
    }
    else
    {
      return false;
    }
  }  

  @Override
  public String toString()
  {
    return toStringHelper(this).addValue(uuid)
                               .addValue(message)
                               .addValue(datestamp)
                               .toString();
  }
}
