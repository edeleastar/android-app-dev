package app.controllers;

import java.util.List;

import app.api.JsonParsers;
import app.api.Rest;
import app.model.Tweet;
import app.model.User;


public class TweetsAPI
{ 
  public static List<Tweet> getTweets(User user) throws Exception
  {
    String response =  Rest.get("/api/users/" + user.uuid + "/tweets");
    List<Tweet> donationList = JsonParsers.json2Tweets(response);
    return donationList;
  }
  
  public static Tweet createTweet(User user, Tweet tweet) throws Exception
  {
    //Routing: api/users/{userId}/tweets   TweetsAPI.createTweet
    String response = Rest.post ("/api/users/" + user.uuid + "/tweets", JsonParsers.tweet2Json(tweet));
    return JsonParsers.json2Tweet(response);
  }
  
  public static void deleteTweet(User user, Tweet tweet) throws Exception
  {
    Rest.delete ("/api/users/" + user.uuid + "/tweets/" + tweet.uuid);
  } 
  
  public static void deleteAllTweets(User user) throws Exception
  {
    Rest.delete ("/api/users/" + user.uuid + "/tweets");
  } 
}