package org.wit.myrent.activities;

import java.io.IOException;
import java.util.UUID;

import org.wit.myrent.R;

import android.support.v4.app.Fragment;
import android.app.Activity;
import android.content.Intent;
import android.hardware.Camera;
import android.hardware.Camera.Size;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import static org.wit.android.helpers.CameraHelper.getBestSupportedSize;
import static org.wit.android.helpers.LogHelpers.info;
import static org.wit.android.helpers.FileIOHelper.write;

public class MyRentCameraFragment extends Fragment implements SurfaceHolder.Callback,
                                                              OnClickListener,
                                                              Camera.ShutterCallback,
                                                              Camera.PictureCallback


{
  public static final String EXTRA_PHOTO_FILENAME = "org.wit.myrent.photo.filename";
  private Camera camera;
  private SurfaceView surfaceView;
  private View progressContainer;


  @Override
  public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState)
  {
    View v = inflater.inflate(R.layout.fragment_myrent_camera, parent, false);
    Button takePictureButton = (Button) v.findViewById(R.id.myrent_camera_takePictureButton);
    takePictureButton.setOnClickListener(this);

    surfaceView = (SurfaceView) v.findViewById(R.id.myrent_camera_surfaceView);
    SurfaceHolder holder = surfaceView.getHolder();
    holder.addCallback(this);
    
    progressContainer = v.findViewById(R.id.myrent_camera_progressContainer);
    progressContainer.setVisibility(View.INVISIBLE);
    
    return v;
  }
  
  @Override
  public void onResume()
  {
    super.onResume();
    camera =  Camera.open(0);
  }
  
  @Override 
  public void onPause()
  {
    super.onPause();
    if(camera != null)
    {
      camera.release();
      camera = null;
    }
  }
  
  //Surface holder callback start methods implementation
  public void surfaceCreated(SurfaceHolder holder)
  {
    // tell the camera to use this surface as its preview area
    try
    {
      if (camera != null)
      {
        camera.setPreviewDisplay(holder);
      }
    }
    catch (IOException exception)
    {
      info(this,"Error setting up preview display "+exception.getMessage());
    }
  }

  public void surfaceDestroyed(SurfaceHolder holder)
  {
    // we can no longer display on this surface, so stop the preview.
    if (camera != null)
    {
      camera.stopPreview();
    }
  }


  public void surfaceChanged(SurfaceHolder holder, int format, int w, int h)
  {
    if (camera == null)
      return;

    // the surface has changed size; update the camera preview size
    Camera.Parameters parameters = camera.getParameters();
    //set best preview size
    Size s = getBestSupportedSize(parameters.getSupportedPreviewSizes(), w, h);
    parameters.setPreviewSize(s.width, s.height);
    //set best picture size
    s = getBestSupportedSize(parameters.getSupportedPictureSizes(), w, h);
    parameters.setPictureSize(s.width, s.height);
    camera.setParameters(parameters);
    try
    {
      camera.startPreview();
    }
    catch (Exception e)
    {
      info(this, "Could not start preview " + e.getMessage());
      camera.release();
      camera = null;
    }
  }
  
  //OnClickListener (camera button)
  @Override
  public void onClick(View v)
  {
    if (camera != null)
    {
      camera.takePicture(this, null, this);
    }
  }

  @Override
  public void onPictureTaken(byte[] data, Camera camera)
  {
    // create a filename
    String filename = UUID.randomUUID().toString() + ".jpg";
    if(write(getActivity(), filename, data) == true)
    {
      Intent i = new Intent();
      i.putExtra(EXTRA_PHOTO_FILENAME, filename);
      getActivity().setResult(Activity.RESULT_OK, i);      
    }
    else
    {
      getActivity().setResult(Activity.RESULT_CANCELED);
    }
    getActivity().finish();
  }

  @Override
  public void onShutter()
  {
    // display the progress indicator
    progressContainer.setVisibility(View.VISIBLE);  
  }

}
