package org.wit.android.helpers;

import java.util.List;

import android.hardware.Camera.Size;

public class CameraHelper
{
  /**
   * a simple algorithm to get the largest size available. For a more robust
   * version, see CameraPreview.java in the ApiDemos sample app from Android.
   */
  public static Size getBestSupportedSize(List<Size> sizes, int width, int height)
  {
    Size bestSize = sizes.get(0);
    int largestArea = bestSize.width * bestSize.height;
    for (Size s : sizes)
    {
      int area = s.width * s.height;
      if (area > largestArea)
      {
        bestSize = s;
        largestArea = area;
      }
    }
    return bestSize;
  }
}
