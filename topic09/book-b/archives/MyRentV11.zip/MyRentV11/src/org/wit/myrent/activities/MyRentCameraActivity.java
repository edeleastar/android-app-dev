package org.wit.myrent.activities;


import org.wit.myrent.R;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.view.Window;
import android.view.WindowManager;

public class MyRentCameraActivity extends FragmentActivity// extends SingleFragmentActivity
{
  @Override
  public void onCreate(Bundle savedInstanceState)
  {
    // hide the window title.
    requestWindowFeature(Window.FEATURE_NO_TITLE);
    // hide the status bar and other OS-level chrome
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    super.onCreate(savedInstanceState);
    setContentView(R.layout.fragment_container);

    FragmentManager manager = getSupportFragmentManager();
    Fragment fragment = manager.findFragmentById(R.id.fragmentContainer);
    if (fragment == null)
    {
      fragment = createFragment();
      manager.beginTransaction().add(R.id.fragmentContainer, fragment).commit();
    }
  }

  private Fragment createFragment()
  {
    return new MyRentCameraFragment();
  }
}
